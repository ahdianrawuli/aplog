﻿/**
* Classes around Google charts.
* @namespace vd.gc
*/