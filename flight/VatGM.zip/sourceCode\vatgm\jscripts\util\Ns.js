﻿/**
* Utilities.
* @namespace vd.util
*/