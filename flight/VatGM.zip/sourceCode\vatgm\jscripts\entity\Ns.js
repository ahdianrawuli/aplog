﻿/**
* Entities such as Flight, Airport.
* @namespace vd.entity
*/