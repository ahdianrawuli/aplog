This directory contains version information.
Version information will be created by the documentation batch file.
Or run hg parents --template {latesttag}+{latesttagdistance}