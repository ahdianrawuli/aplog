﻿----------------------------------------------------------------------------------------------
All VATSIM data files contain data of pilots / ATC and MUST only be used
in the context of this application for testing purposes. Do not share / distribute these data.
----------------------------------------------------------------------------------------------

Standard:
1_vatsim-data.txt 1..9 Standard development test data
VATRoute01 ... test routes

Noteworthy:
D1_vatsim-data-txt	CHR2 as helicopter  