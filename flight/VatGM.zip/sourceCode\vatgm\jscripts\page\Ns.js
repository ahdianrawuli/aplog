﻿/**
* Code "behind" the page, somehow like the controller methods of the page view.
* @namespace vd.page
*/