﻿/**
* Base entities for maps and VATSIM objects. Superclasses for most entities.
* @namespace vd.entity.base
*/